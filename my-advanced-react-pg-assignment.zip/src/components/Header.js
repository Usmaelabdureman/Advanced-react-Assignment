import React, { useEffect, useRef, useState } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faEnvelope } from "@fortawesome/free-solid-svg-icons";
import {
  faGithub,
  faLinkedin,
  faMedium,
  faStackOverflow,
} from "@fortawesome/free-brands-svg-icons";
import { Box, Flex, HStack,Link,ListItem,UnorderedList } from "@chakra-ui/react";

const socials = [
  {
    id:"email",
    icon: faEnvelope,
    url: "mailto: uabdureman@gmail.com",
  },
  {
    id:"github",
    icon: faGithub,
    url: "https://github.com/Usmaelabdureman/",
  },
  {
    id:"linkedin",
    icon: faLinkedin,
    url: "https://www.linkedin.com/in/usmael",
  },
  {
    id:"medium",
    icon: faMedium,
    url: "https://medium.com/usmael",
  },
  {id:"stackoverflow",
    icon: faStackOverflow,
    url: "https://stackoverflow.com/users/20668911/usmael-abdurhaman-esmizth",
  },
];

const Header = () => {
  const [prevScrollPos, setPrevScrollPos] = useState(0);
  const [isVisible, setIsVisible] = useState(true);
  const headerRef = useRef(null);

  const handleScroll = () => {
    const currentScrollPos = window.pageYOffset;
    const delta = 5;
    const isScrollingUp = prevScrollPos > currentScrollPos;
    const shouldHideHeader = isScrollingUp && currentScrollPos > 0;

    if (shouldHideHeader) {
      setIsVisible(false);
    } else {
      if (isScrollingUp) {
        setIsVisible(true);
      }
    }
    setPrevScrollPos(currentScrollPos);
  };

  useEffect(() => {
    window.addEventListener("scroll", handleScroll);
    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, [prevScrollPos, isVisible]);

  const handleClick = (anchor) => () => {
    const id = `${anchor}-section`;
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({
        behavior: "smooth",
        block: "start",
      });
    }
  };

  return (
    <Box
    ref={headerRef}
      position="fixed"
      top={0}
      left={0}
      right={0}
      transform={isVisible ? "translateY(0)" : "translateY(-200px)"}
      transitionProperty="transform"
      transitionDuration=".3s"
      transitionTimingFunction="ease-in-out"
      backgroundColor="#18181b"
      zIndex="9999"
    >
      <Box color="white" maxWidth="1280px" margin="0 auto">
        <HStack
          px={16}
          py={4}
          justifyContent="space-between"
          alignItems="center"
          
        >
          <nav>
            {/* Add social media links based on the `socials` data */}
            <UnorderedList listStyleType='none'display="flex" flexDirection="row">
              {socials.map((link) =>(
                <ListItem key={link.id} ml={4}>
                  <Link href={link.url}>
                     <FontAwesomeIcon icon={link.icon} />
                 </Link>
               </ListItem>
              ))
              }
            </UnorderedList>   
            </nav>
            <nav>
            <HStack spacing={6} >
              {/* Add links to Projects and Contact me section */}
              <UnorderedList listStyleType="none" display="flex" flexDirection="row">
                <ListItem >
                  <Link href="#projects" onClick={handleClick("projects")}>Projects</Link>
                </ListItem>
                <ListItem ml={4}>
                  <Link href="#contact-me" onClick={handleClick("contactme")}>Contact Me</Link>
                </ListItem>
              </UnorderedList>
            </HStack>
            </nav>
        </HStack>
      </Box>
    </Box>
  );
};
export default Header;
